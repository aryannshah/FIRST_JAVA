import java.util.Scanner;

public class Test {
	public static boolean a_number(int number) {
		int og_number=number;
		int sumofcubes = 0;
		
		while(number>0) {
			int digit=number%10;
			sumofcubes += Math.pow(digit, 3);
			number /=10;
		}
		return sumofcubes == og_number;
	}
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		
		if(a_number(num)) {
			System.out.println("It is an armstrong number");
			
		}
		else {
			System.out.println("It is not a armstrong number");
			
		}

	}

}
