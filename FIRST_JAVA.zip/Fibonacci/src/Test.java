import 	java.util.Scanner;
class fib{
	int a=0,b=1,n=10,c;
	public void fibonacci_series() {
		System.out.println(a);
		if (n<1)
			return;
		for(int i=1;i<n;i++) {
			
			System.out.println(a);
			int c=a+b;
			a=b;
			b=c;
			
		}
	}
}
public class Test {

	public static void main(String[] args) {
		fib fibo=new fib();
		fibo.fibonacci_series();

	}

}
