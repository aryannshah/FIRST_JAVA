import java.util.Scanner;
class large{
	public void fun() {
		int n1,n2,n3;
		System.out.println("Enter number n1: ");
		Scanner sc=new Scanner(System.in);
		n1=sc.nextInt();
		
		System.out.println("Enter number n2: ");
		n2=sc.nextInt();
		
		System.out.println("Enter number n3: ");
		n3=sc.nextInt();
		
		if(n1>n2 && n1>n3) {
			System.out.println(n1 + " is the biggest number");
		}
		else if(n2>n3 && n2>n1) {
			System.out.println(n2 + " is the biggest number");
			}
		else
			System.out.println(n3 + " is the biggest number");
		
		
	}
}
public class Test {

	public static void main(String[] args) {
		large l1=new large();
		l1.fun();

	}

}
