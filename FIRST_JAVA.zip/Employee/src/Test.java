import java.util.Scanner;
class employee{
	int salary,total,bonus,employ_id;
	String department,name;
	public void fun() {
		System.out.println("Enter Employee Name: ");
		Scanner sc=new Scanner(System.in);
		name=sc.next();
		
		System.out.println("Enter Depatment: ");
		department=sc.next();
		
		System.out.println("Enter Employ_id: ");
		employ_id=sc.nextInt();
		
		System.out.println("Enter Salary: ");
		salary=sc.nextInt();
		
		System.out.println("Enter bonus in percentage: ");
		bonus=sc.nextInt();
		
		total=salary+salary*bonus/100;
		System.out.println("Total salary: "+total);
		
		System.out.println(name+" "+employ_id+" "+department+" "+salary+" "+bonus+" "+total);
		
		
	}
}
public class Test {

	public static void main(String[] args) {
		employee e1=new employee();
		e1.fun();

	}

}
