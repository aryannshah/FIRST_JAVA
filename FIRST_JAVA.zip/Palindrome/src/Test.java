import java.util.Scanner; 
class pali {
	boolean flag=true;
	public void palin() {
		System.out.println("Enter a string: ");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		name=name.toLowerCase();
		for(int i=0;i<name.length()/2;i++) {
			if(name.charAt(i)!=name.charAt(name.length()-i-1)) {
				flag=false;
				break;
			}
		}
		if(flag)
			System.out.println("Given string is palindrome");
		else
			System.out.println("Given string is not a palindrome");
	}
}

public class Test {

	public static void main(String[] args) {
		pali p1=new pali();
		p1.palin();
		

	}

}
