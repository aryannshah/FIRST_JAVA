import java.util.Scanner;
class BankAccount{
	int account_number,amount,balance,damount,wamount;
	String name,typ;
	public void Withdraw() {
		System.out.println("Enter Amount to be Withdrawn: ");
		Scanner sc=new Scanner(System.in);
		wamount=sc.nextInt();
		if(balance>=wamount) {
			balance=balance-wamount;
			System.out.println("Balance is: "+balance);
			
			}
		else
			System.out.println("Balance is less than withdrawn amount");
	}
	public void Deposit() {
		System.out.println("Enter the Amount to be Deposited: ");
		Scanner sc1=new Scanner(System.in);
		damount=sc1.nextInt();
		balance=balance+damount;
		System.out.println("Balance is: "+balance);
	}
	public void Check_Balance() {
		System.out.println("Your Balance is: "+balance);
	}
	public void fun() {
		System.out.println("Enter Account Holder Name: ");
		Scanner sc3=new Scanner(System.in);
		name=sc3.next();
		
		System.out.println("Enter Account No: ");
		account_number=sc3.nextInt();
		
		System.out.println("Enter Account balance: ");
		balance=sc3.nextInt();
		
		
	}
	
}
public class Test {

	public static void main(String[] args) {
		BankAccount b1=new BankAccount();
		b1.fun();
		String typ;
		System.out.println("Select withdraw,deposit,check_balance: ");
		Scanner sc3=new Scanner(System.in);
		typ=sc3.next();
		switch(typ) {
		case "withdraw":
			b1.Withdraw();
			break;
		case "deposit":
			b1.Deposit();
			break;
		case "check_balance":
			System.out.println("Your Balance is: ");
			b1.Check_Balance();
			break;
		}

	}

}
