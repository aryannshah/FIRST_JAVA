import java.util.Scanner;
class rev {
	
	public void fun() {
		int reverse=0;
		System.out.println("Enter a number: ");
		Scanner sc=new Scanner(System.in);
		int num= sc.nextInt();
		while(num!=0) {
			int remainder=num%10;
			reverse=reverse*10+remainder;
			num=num/10;
			System.out.println("Reversed Number: "+reverse);
		}
	}
}
public class Test {

	public static void main(String[] args) {
		rev r1=new rev();
		r1.fun();

	}

}
