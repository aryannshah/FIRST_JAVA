class shape{
	int l,b;
	float r,a,pi;
	
	public void area(int l,int b) {
		a = l*b;
		System.out.println("Area of rectangle "+a);
	}
	
	public void area(int l) {
		a = l*l;
		System.out.println("Area of square "+a);
	}
	
	public void area(float pi,float r) {
		a= pi*r*r;
		System.out.println("Area of circle "+a);
		
	}
}
public class Test {

	public static void main(String[] args) {
		
		shape s1=new shape();
		s1.area(10);
		s1.area(10, 5);
		s1.area(3.14f,2);
		
		shape s2=new shape();
		s2.area(5);
		
		
		

	}

}
