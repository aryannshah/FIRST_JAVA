import java.util.Scanner;
class Test {
	int a,b,n,i;
	public void prime() {
		System.out.println("Enter a number: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		if(n==2)
		System.out.println("It is a prime number");
		else
			for(int i=2;i<n;i++) {
				if(n%i==0)
					System.out.println("It is not a prime number");
				else
					System.out.println("It is a prime number");
			
			
		
			}
		
		
	}


	public static void main(String[] args) {
		Test f1=new Test();
		f1.prime();
		

	}

}
