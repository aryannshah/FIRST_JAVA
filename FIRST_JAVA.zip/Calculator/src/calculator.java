import java.util.Scanner;

class cal{
	int a,b,c;
	
	public void addition() {
		System.out.println("Enter a: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		System.out.println("Enter b: ");
		b=sc.nextInt();
		System.out.println(a+b);
	}
	
	public void subtraction() {
		System.out.println("Enter a: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		System.out.println("Enter b: ");
		b=sc.nextInt();
		System.out.println(a-b);
	}
	
	public void multiplication() {
		System.out.println("Enter a: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		System.out.println("Enter b: ");
		b=sc.nextInt();
		System.out.println(a*b);
		
	}
	public void division() {
		System.out.println("Enter a: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		System.out.println("Enter b: ");
		b=sc.nextInt();
		System.out.println(a/b);
		try {
			c=a/b;
		}
		catch(Exception e) {
			System.out.println("Exception: "+e);
		}
	}
}	
public class calculator{
	


	public static void main(String[] args) {
		cal calci = new cal();
		String typ;
		System.out.println("Select add,sub,mul,div: ");
		Scanner sc = new Scanner(System.in);
		typ=sc.next();
		switch(typ) {
			case "add":
				calci.addition();
				break;
			case "sub":
				calci.subtraction();
				break;
			case "mul":
				calci.multiplication();
				break;
			case "div":
				calci.division();
				break;
			
		}
		

	}

}
