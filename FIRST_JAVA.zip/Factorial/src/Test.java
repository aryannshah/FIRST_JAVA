import java.util.Scanner;

class factorial{
	int a;
	int fact=1;
	public void fact() {
		System.out.println("Enter a number: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		for(int i=1;i<=a;i++) {
			fact=fact*i;
		System.out.println("factorial of "+a +" is: "+fact);
		}
		
	}
}
public class Test {

	public static void main(String[] args) {
		factorial facto=new factorial();
		facto.fact();

	}

}
