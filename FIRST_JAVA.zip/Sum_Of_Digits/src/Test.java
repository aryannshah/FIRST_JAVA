import java.util.Scanner;
class sum{
	int a,b,c=0,n;
	public void func() {
		System.out.println("Enter a number: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		while(a>0) {
			b=a%10;
			c+=b;
			a=a/10;
			
			System.out.println("Sum of Digits: "+c);
		}
	}
}

public class Test {

	public static void main(String[] args) {
		sum s1=new sum();
		s1.func();

	}

}
