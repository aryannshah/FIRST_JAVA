import java.util.Scanner;
class swap{
	int a=10,b=15,c;
	public void fun() {
		System.out.println("Before Swap a= "+a+" b= "+b);
		c=a;
		a=b;
		b=c;
		System.out.println("After Swap a= "+a+" b= "+b);
			
	}
}
public class Test {

	public static void main(String[] args) {
		swap s1=new swap();
		s1.fun();

	}

}
