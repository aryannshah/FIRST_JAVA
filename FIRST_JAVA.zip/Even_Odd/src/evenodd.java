import java.util.Scanner;

class test{
	
	int a;
	public void oddeven() {
		
	System.out.println("Enter a number: ");
	Scanner sc=new Scanner(System.in);
	a=sc.nextInt();
	if (a%2 ==0) {
		System.out.println(a+ " is an even number");
	}
	else {
		System.out.println(a+ " is an odd number");
	}
	}
	
}
public class evenodd {

	public static void main(String[] args) {
		test fun=new test();
		fun.oddeven();
		

	}

}
