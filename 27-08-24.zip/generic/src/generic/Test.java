package generic;

public class Test {

}
