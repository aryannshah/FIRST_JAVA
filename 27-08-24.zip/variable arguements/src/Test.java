import java.util.Scanner;

public class Test {
	
	public static int add(int ...a) {
		int sum=0;
		for(int i=0;i<a.length;i++) {
			sum=sum+a[i];
		}
		return sum;
	}
	public void method1(int a[]) {
		System.out.println("Enter your variable: ");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(add(10,20,20));
		System.out.println(add(10,20,20,30,30));
		
			
		}
		
		

	}

}
