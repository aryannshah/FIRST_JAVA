import java.util.Scanner;
class maxmin{
	int max;
	public void maximum(int a[]) {
		max=a[0];
		for(int i=0;i<a.length;i++) {
			if(a[i]>max) {
				max=a[i];
			}
			
		}
		System.out.println(max+ " is the largest number");
	}
	public void minimum(int a[]) {
		int min;
		min=a[0];
		for(int i=0;i<a.length;i++) {
			if(a[i]<min) {
				min=a[i];
			}
			
		}
		System.out.println(min+ " is the smallest number");
	}
	public void array2(int a[]) {
		int []b=new int[5];
		for(int i=0;i<b.length;i++) {
			b[i]=a[i]*5;
		}
		System.out.println("Second array is: ");
		for(int val:b) {
			System.out.println(val);
		}
		System.out.println();
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a=new int [5];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any five integers: ");
		for(int i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		
		maxmin m1=new maxmin();
		m1.maximum(a);
		m1.minimum(a);
		m1.array2(a);
		

	}

}
