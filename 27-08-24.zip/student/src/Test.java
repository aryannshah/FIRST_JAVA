//Write a class Student with members for rollno, name and percentage. Implement necessary methods inside class. Write a code to print number of objects created for class Student. Use static.
// Implement getter/setter methods and method “toString” in above class Student.
import java.util.Scanner;
public class Test {
	String name;
	int rollno,count;
	double percentage;
	
	public student(int rollno, String name, double percentage) {
		this.rollno=rollno;
		this.name=name;
		this.percentage;
		count++;
	}
	
		System.out.println("Enter Student rollno: ");
		public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getRollno() {
		return rollno;
	}



	public void setRollno(int rollno) {
		this.rollno = rollno;
	}



	public int getCount() {
		return count;
	}



	public void setCount(int count) {
		this.count = count;
	}



	public double getPercentage() {
		return percentage;
	}



	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

		Scanner sc1=new Scanner(System.in);
		number=sc1.nextInt();
		
		System.out.println("Enter Student percentage: ");
		Scanner sc2=new Scanner(System.in);
		percentage=sc2.nextInt();
		
	public void count() {
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
