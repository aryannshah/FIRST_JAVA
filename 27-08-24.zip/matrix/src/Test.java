//Write a program to accept and display 3 by 3 matrix. Use enhanced for loop for display.
//a. Find the transpose of a matrix and print the transpose.
//b. Accept another matrix of same dimensions. Find the addition of two matrices and print the resultant matrix.


import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]a=new int[3][3];
		int [][]transpose=new int[3][3];
		int [][]add=new int[3][3];
		int [][]result=new int[3][3];
		
		System.out.println("Enter the numbers: ");
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[i].length;j++) {
				a[i][j]=sc.nextInt();
			}
		}
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[i].length;j++) {
				transpose[i][j]=a[j][i];
			}
		}	
		for(int [] val1: a) {
			for(int val2: val1) {
				System.out.print(val2+ " ");
			}
			System.out.println();
		}
		
		for(int [] val1: transpose) {
			for(int val2: val1) {
				System.out.print(val2+ " ");
			}
			System.out.println();
		}
		System.out.println("Enter the numbers for addition: ");
		Scanner sc1=new Scanner(System.in);
		for(int i=0;i<add.length;i++) {
			for(int j=0;j<add[i].length;j++) {
				add[i][j]=sc1.nextInt();
			}
		}
		for(int i=0;i<add.length;i++) {
			for(int j=0;j<add[i].length;j++) {
				result[i][j]=transpose[i][j]+add[i][j];
			}
		}
		for(int [] val1: result) {
			for(int val2: val1) {
				System.out.print(val2+ " ");
			}
			System.out.println();
		}

	}

}
