import java.util.Scanner;
class AccountHolder{
	private int ac_no;
	private int balance;
	private String ac_name;
	
	public AccountHolder(int ac_no,int balance, String ac_name) {
		this.ac_no = ac_no;
		this.balance = balance;
		this.ac_name = ac_name;
	}

	public int getAc_no() {
		return ac_no;
	}

	public void setAc_no(int ac_no) {
		this.ac_no = ac_no;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getAc_name() {
		return ac_name;
	}

	public void setAc_name(String ac_name) {
		this.ac_name = ac_name;
	}
	
	public void deposit(int amt) {
		balance=amt+balance;
	}
	
	public void withdraw(int amt) {
		balance=balance-amt;
	}
	
	public void details() {
		System.out.println(ac_no+"\t"+ac_name+"\t"+balance);
	}
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cnt=0,choice,acno,wamt;
		AccountHolder acc[]=new AccountHolder[10];
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("1. Add Account Details");
			System.out.println("2. Display Accopunt Details");
			System.out.println("3. Deposit amount");
			System.out.println("4. Withdraw amount");
			System.out.println("5. Exit");
			
			System.out.println("Enter your choice: ");
			choice=sc.nextInt();
			switch(choice) 
			{
			case 1:
				System.out.println("Enter Account Number, Balance, Account Holder");
				acc[cnt++]=new AccountHolder(sc.nextInt(),sc.nextInt(),sc.next());
				break;
			case 2:
				System.out.println("All Account Details");
				for(int i=0;i<cnt;i++) {
					acc[i].details();
				}
				break;
				
			case 3:
				System.out.println("Enter Account Number for deposit: ");
				acno=sc.nextInt();
				for(int i=0;i<cnt;i++) {
					if(acno==acc[i].getAc_no()) {
						System.out.println("Amount deposit: ");
						acc[i].deposit(sc.nextInt());
						
					}
				}
				break;
			case 4:
				System.out.println("Enter Account Number for withdraw: ");
				acno=sc.nextInt();
				for(int i=0;i<cnt;i++) {
					if(acno==acc[i].getAc_no()) {
						System.out.println("Amount Withdraw: ");
						wamt=sc.nextInt();
						if(wamt>acc[i].getBalance()) {
							System.out.println("Insufficient Balance");
						}
						else {
							acc[i].withdraw(wamt);
						}
						
					}
					else {
						System.out.println("Account details not found");
					}
				}
				break;
			case 5:
				System.exit(0);
			
			}
		}

	}

}
