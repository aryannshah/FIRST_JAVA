interface printable{
	void PrintDetails(String name, int score);
}
class cktPlayers implements printable{

	@Override
	public void PrintDetails(String name, int score) {
		System.out.println("Name: "+name+" "+"Runs: "+score);
		// TODO Auto-generated method stub
		
	}
	
}
class ftPlayers implements printable{

	@Override
	public void PrintDetails(String name, int score) {
		System.out.println("Name: "+name+" "+"Goals: "+score);
		// TODO Auto-generated method stub
		
	}
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		cktPlayers p1=new cktPlayers();
		p1.PrintDetails("Aryan", 100);
		
		System.out.println();
		
		ftPlayers f1=new ftPlayers();
		f1.PrintDetails("Drashti", 3);

	}

}
