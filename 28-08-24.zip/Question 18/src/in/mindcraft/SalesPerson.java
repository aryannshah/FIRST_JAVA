package in.mindcraft;

public class SalesPerson extends WageEmployee {
	int item_sold;
	int commission_per_item;
	int hrs;
	int rate;
	public SalesPerson() {
		item_sold=0;
		commission_per_item=0;
	}
	public SalesPerson(int item_sold, int commission_per_item,String name, int emp_id, int dd, int mm, int yy,int hrs,int rate) {
		super(name,emp_id,dd,mm,yy,hrs,rate);
		this.item_sold = item_sold;
		this.commission_per_item = commission_per_item;
		this.hrs=hrs;
		this.rate=rate;
	}
	public void show() {
		System.out.println("Number of Items: "+item_sold);
		System.out.println("Rate per item: "+commission_per_item);
		System.out.println("Sales Person Salary: "+((hrs*rate+item_sold*commission_per_item)));
	}

}
