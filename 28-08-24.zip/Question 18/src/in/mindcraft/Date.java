package in.mindcraft;


public class Date {
	int dd,mm,yy;
	public Date() {
		this.dd=1;
		this.mm=1;
		this.yy=2024;
	}
	public Date(int dd,int mm,int yy) {
		this.dd=dd;
		this.mm=mm;
		this.yy=yy;
	}
	
	public void show() {
		System.out.println(dd+"/"+mm+"/"+yy);
	}

}

