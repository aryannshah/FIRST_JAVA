package in.mindcraft;

public class Employee {
	String name;
	int emp_id;
	Date dob;
	public Employee() {
		name="Aryan";
		emp_id=100;
		dob=new Date();
	}

	
	public Employee(String name, int emp_id, int dd, int mm, int yy) {
		this.name = name;
		this.emp_id = emp_id;
		this.dob = new Date(dd,mm,yy);
	}


	public void show() {
		System.out.println("Name: "+name);
		System.out.println("EmployeeID: "+emp_id);
		dob.show();
	}

}
