package in.mindcraft;

public class WageEmployee extends Employee {
	private int hrs;
	private int rate;
	
	public  WageEmployee() {
		hrs=0;
		rate=0;
	}
	public WageEmployee(String name, int emp_id, int dd, int mm, int yy,int hrs,int rate) {
		super(name,emp_id,dd,mm,yy);
		this.hrs = hrs;
		this.rate = rate;
	}
	public void show() {
		System.out.println("Working hours: "+hrs);
		System.out.println("Rate per hour: "+rate);
		System.out.println("Wage of Employee: "+hrs*rate);
	}
	
	
}

