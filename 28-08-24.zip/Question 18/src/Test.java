import in.mindcraft.*;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WageEmployee w1= new WageEmployee("Aryan", 100, 17, 11, 24, 9, 1000);
		w1.show();
		
		SalesPerson w2=new SalesPerson(55,20,"Drashti",101,10,05,24,10,950);
		w2.show();

	}

}