package com.mindcraft.pack2;

public class Batch {
	String CourseName;
	int BatchStrength;
	
public Batch(String CourseName,int BatchStrength) {
	this.CourseName=CourseName;
	this.BatchStrength=BatchStrength;
	}

public void display() {
	System.out.println("The CourseName is: "+CourseName);
	System.out.println("The BatchStrength is: "+BatchStrength);
	}
}
	
