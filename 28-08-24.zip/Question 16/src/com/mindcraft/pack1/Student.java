package com.mindcraft.pack1;

public class Student {
	int RollNo;
	String name;
	
public Student(int RollNo,String name){
	this.RollNo=RollNo;
	this.name=name;
	}

public void display() {
	System.out.println("The roll no. of student is: "+RollNo);
	System.out.println("The name of the student is: "+name);
	}
}