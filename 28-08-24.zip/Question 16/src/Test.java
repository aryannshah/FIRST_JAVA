import com.mindcraft.pack1.*;
import com.mindcraft.pack2.*;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student(101,"Aryan");
		Student s2=new Student(102,"Drashti");
		
		Batch b1=new Batch("Java",20);
		Batch b2=new Batch("python",50);
		
		System.out.println("Student Details: ");
		s1.display();
		s2.display();
		System.out.println("Batch Details: ");
		b1.display();
		b2.display();
				

	}

}
