import in.mindcraft.*;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager m1=new Manager(100, "Aryan", 10000);
		m1.show();
		System.out.println();
		MarketingExecutive m2=new MarketingExecutive(100, 101, 10000, "Aryan");
		m2.show();

	}

}
