package in.mindcraft;

public class MarketingExecutive extends Employee {
	int distance;
	int tour_all;
	int tel_all;
	int pf;
	int net_sal;
	int gross_sal;
	public MarketingExecutive() {
		distance=0;
		tour_all=0;
		tel_all=0;
		pf=0;
		net_sal=0;
		gross_sal=0;
	}
	public MarketingExecutive(int distance,int emp_id, int salary, String name) {
		super(emp_id,name,salary);
		this.distance = distance;
		this.tour_all = 5*distance;
		this.tel_all = 2000;
		this.pf = 125*salary/1000;
		this.gross_sal = salary+(5*distance)+2000;
		this.net_sal = gross_sal-pf;
		
		}
	
	public void show() {
		System.out.println("Total Distance Travelled: "+distance);
		System.out.println("Tour Allowance: "+tour_all);
		System.out.println("Telephone Allowance: "+tel_all);
		System.out.println("PF: "+pf);
		System.out.println("Net salary: "+net_sal);
		System.out.println("Gross salary: "+gross_sal);
	}
	

}
