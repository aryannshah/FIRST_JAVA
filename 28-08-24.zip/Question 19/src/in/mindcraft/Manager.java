package in.mindcraft;

public class Manager extends Employee {
	int pet_all;
	int food_all;
	int other_all;
	int gross_sal;
	int net_sal;
	int total_all;
	int pf;
	public Manager() {
		pet_all=0;
		food_all=0;
		other_all=0;
		total_all=0;
		gross_sal=0;
		net_sal=0;
		pf=0;
	}
	public Manager(int emp_id,String name, int salary) {
		super(emp_id,name,salary);
		this.pet_all = 8*salary/100;
		this.food_all = 12*salary/100;
		this.other_all = 4*salary/100;
		this.total_all = 24*salary/100;
		this.pf = 125*salary/1000;
		this.gross_sal = salary+total_all;
		this.net_sal = gross_sal-pf;
		
	}
	public void show() {
		System.out.println("Total Petrol Allowance is: "+pet_all);
		System.out.println("Total Food Allowance is: "+food_all);
		System.out.println("Total Other Allowance is: "+other_all);
		System.out.println("PF is: "+pf);
		System.out.println("Gross salary is: "+gross_sal);
		System.out.println("Net salary is: "+net_sal);
	}
	

}
