package in.mindcraft;

public class Employee {
	int emp_id;
	int salary;
	String name;
	public Employee() {
		emp_id=1;
		salary=1000;
		name="Aryan";
	}
	public Employee(int emp_id,String name, int salary) {
		this.emp_id = emp_id;
		this.salary = salary;
		this.name = name;
	}
	public void show() {
		System.out.println("Employee name: "+name);
		System.out.println("Employee ID: "+emp_id);
		System.out.println("Employee Basic Salary: "+salary);
	}
	

}
