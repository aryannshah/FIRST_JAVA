import java.util.Random;

public class Student {
	private static int rollnogen=1000;
	int rollno;
	String name;
	Date dob;
	public Student() {
		this.rollno= generateRollNumber();
		this.name="";
		this.dob=new Date();
	}
	public Student(String name,Date dob) {
		this.rollno = generateRollNumber();
        this.name = name;
        this.dob = dob;
	}
	public int generateRollNumber() {
		return rollnogen++;
	}
	
	public void accept(String name,Date dob) {
		this.name=name;
		this.dob=dob;
	}
	
	public void display() {
		System.out.println("The name of the student is: "+name);
		System.out.println("Roll No.: "+rollno);
		System.out.println("Date of birth is: ");
		dob.display();
	}
}
