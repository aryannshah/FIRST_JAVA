
public class Date {
	int day,month,year;
	public Date() {
		this.day=17;
		this.month=11;
		this.year=2002;
	}
	
	public Date(int day, int month, int year) {
		this.day=day;
		this.month=month;
		this.year=year;
	}
	
	public void display() {
		System.out.println(day+"/"+month+"/"+year);
	}
}
