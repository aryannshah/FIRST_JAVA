
public class Test {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date dob1 = new Date(17, 11, 2002);
        Date dob2 = new Date(10, 05, 2002);

        
        Student student1 = new Student("Aryan", dob1);
        Student student2 = new Student("Drashti", dob2);

        // Display student details
        System.out.println("Student Details:");
        student1.display();
        student2.display();
    }


}


